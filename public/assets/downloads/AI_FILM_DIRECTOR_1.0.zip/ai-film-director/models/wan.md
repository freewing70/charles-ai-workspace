# wan adapter
Translate canonical shot state without changing story/world state. Bind only supported references; expose unsupported requirements. Keep creative prompt separate from execution parameters. Verify current official capabilities before automated generation.
