# Model Adapters
Core state is model-independent. Adapters map canonical shot specs into target prompt syntax, reference bindings and actual execution parameters. Verify current official capabilities before automated generation. Unknown remains UNKNOWN. Adapter files are guidance, not API contracts.
