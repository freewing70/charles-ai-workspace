# Changelog
## 1.0.0 — 2026-10-04
Initial public agent-agnostic release.
