# Contributing
Do not submit third-party copyrighted prompt packs, character likenesses, proprietary assets, leaked system prompts, or materials whose license does not permit redistribution. Keep uncertain model capabilities marked UNKNOWN.
