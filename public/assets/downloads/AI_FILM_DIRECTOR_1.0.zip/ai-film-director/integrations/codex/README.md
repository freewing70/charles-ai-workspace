# Codex integration
Install/copy as a skill or project instruction package.
Core semantics and canonical state files must remain unchanged.
