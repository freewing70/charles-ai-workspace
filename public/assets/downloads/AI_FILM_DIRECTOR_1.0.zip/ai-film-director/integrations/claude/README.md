# Claude integration
Use SKILL.md plus core references as project/skill instructions.
Core semantics and canonical state files must remain unchanged.
