# Generic integration
Provide SKILL.md and references as project instructions/context.
Core semantics and canonical state files must remain unchanged.
