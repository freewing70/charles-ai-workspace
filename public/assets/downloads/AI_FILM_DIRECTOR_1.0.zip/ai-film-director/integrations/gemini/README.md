# Gemini integration
Use SKILL.md and core references as persistent project instructions/context where supported.
Core semantics and canonical state files must remain unchanged.
