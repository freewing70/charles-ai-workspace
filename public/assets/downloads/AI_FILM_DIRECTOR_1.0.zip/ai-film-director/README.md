# AI Film Director
Agent-agnostic AI filmmaking production skill for consistent assets, world state, acting, cinematography, prompt compilation, generation management, QC and continuity across AI video models.

## Install
Give this repository/folder to your agent as a skill, project instruction set, or persistent context. Start with `SKILL.md`.

## Quick start
“Use AI Film Director. Story: … Characters: … Duration: 30 seconds. Style: …”

## License
Original code and documentation are MIT licensed. Third-party research sources are not bundled or relicensed; see `THIRD_PARTY_NOTICES.md`.
