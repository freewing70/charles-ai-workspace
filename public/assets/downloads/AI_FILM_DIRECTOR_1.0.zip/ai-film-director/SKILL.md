---
name: ai-film-director
description: Agent-agnostic AI filmmaking production system.
version: 1.0.0
---
# AI Film Director
Structured production state is the source of truth; prompts are compiled outputs.

Inputs: story, characters, target duration, visual style; optionally assets, aspect, language, budget, target model/platform and project folder.
Outputs: manifests, asset registry, world state, scenes/shots, generation routes, prompts, execution parameters, generation log, QC, selections, continuity and edit plan.

## Capability detection
Detect file I/O, code, image/video inspection, image/video generation, web/docs and persistence. Never pretend missing capabilities exist. Degrade gracefully from autonomous production to planning-only.

## Production loop
1. Story → scene beats → edit-time budget → stable IDs.
2. Resolve only required assets; locked masters are immutable.
3. Maintain world-space GEO separately from screen-space blocking.
4. Carry character/environment/prop states across shots.
5. Translate dramatic intent into observable acting.
6. Choose COMPACT_R2V, FULL_R2V, HERO_I2V, MULTICUT_CLIP or T2V.
7. Compile model-independent shot state, then apply a model adapter.
8. Keep creative prompt separate from actual execution parameters.
9. Review actual media. Critical failures block selection.
10. VARIATION keeps controls; REVISION changes the smallest meaningful control and logs it.
11. At attempt/spend cap, redesign rather than blind-regenerate.
12. Record selected generation ID and usable in/out; propagate end state.
13. Human review remains required for final narrative, performance, continuity, sound and publication.

## Invariants
Identity != state. Tags != assets. Generated clip != edit shot. Completed != QC pass. Screen-left != world-left. Prompt claims like 8K/60fps != execution settings. Unknown stays unknown. Never redistribute third-party prompt packs, likenesses, proprietary production materials or copyrighted assets.

Load `core/*.md`, `models/README.md`, schemas/templates and host integration notes as needed.
