# Acting
Translate inner state into observable behavior. Profiles may define center of gravity, tempo, openness, breathing, gaze/blinks, tics, concealment, gait, status, voice, speech rhythm and triggers. Use natural eye life and physical business when useful, never mechanically.
