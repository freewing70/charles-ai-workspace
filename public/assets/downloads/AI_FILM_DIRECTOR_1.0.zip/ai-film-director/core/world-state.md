# World State
`world_state.json` is authoritative for time, locations, characters, props, environment and continuity. Selected shot end-state deltas update the world. Dependent shots inherit automatically; never rely on “same as previous shot”.
