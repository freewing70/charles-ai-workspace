# Story
Scenes have purpose, location, active characters, dramatic state change and edit duration. Planned edit durations sum to target duration. A shot is editorial intent, not a generation job. Keep edit and generation durations separate. Split overloaded action into approach/contact/consequence.
