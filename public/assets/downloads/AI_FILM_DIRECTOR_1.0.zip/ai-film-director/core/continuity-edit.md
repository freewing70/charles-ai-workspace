# Continuity Edit
Compare identity, wardrobe, damage, blood, wetness, props/hands, position, facing, gaze, lighting, weather, environment, ambience, physical state and action handoff. Selection stores actual generation ID, usable in/out, QC evidence, reason and cleanup. Picture lock precedes focused cleanup, color/sound continuity, mix and export.
