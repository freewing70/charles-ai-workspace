# Camera
Store shot size, camera height/distance/angle, lens intent, focus plan, physical path, speed, stabilization, axis and subject priority. Describe visible physical behavior, not vague cinematic adjectives.
