# Assets
Stable asset IDs track logical entity, type, state, version, parent, descriptor, path/reference binding, hash, status and tests. Identity is separate from wardrobe/injury/wetness/armor/age/voice/behavior. Environments can have view/time/weather/damage states; props can have held/damaged/hidden states. Generate only needed variants. Preserve originals; localized edits create children.
