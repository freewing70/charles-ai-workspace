# Geo Blocking
GEO is world-space: landmarks, distances, orientation, world north, light source and stable positions. Blocking is shot-space: subjects, start/screen positions, facing, gaze, contact, paths and end positions. Reverse angles recompute screen positions from world geometry.
