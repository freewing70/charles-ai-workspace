#!/usr/bin/env python3
from pathlib import Path
import sys,shutil
r=Path(sys.argv[1] if len(sys.argv)>1 else 'film-project'); b=Path(__file__).resolve().parents[1]
for p in ['story','assets/characters','assets/environments','assets/props','assets/voices','world','scenes','shots','prompts/compiled','prompts/model-adapted','generations','qc','selections','edit','logs','progress']:(r/p).mkdir(parents=True,exist_ok=True)
for s,d in [('templates/project.json','project.json'),('templates/world_state.json','world/world_state.json')]:
 q=r/d
 if not q.exists(): shutil.copy(b/s,q)
print(r.resolve())
