#!/usr/bin/env python3
from pathlib import Path
import json,sys
r=Path(sys.argv[1]); e=[]
for f in ['project.json','world/world_state.json']:
 p=r/f
 if not p.exists(): e.append('missing '+f)
 else:
  try: json.loads(p.read_text())
  except Exception as x: e.append(f'{f}: {x}')
print('PASS' if not e else 'FAIL\n'+'\n'.join(e)); raise SystemExit(bool(e))
