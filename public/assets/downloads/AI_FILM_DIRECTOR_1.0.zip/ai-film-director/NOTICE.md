# Notice
AI Film Director 1.0 — Copyright (c) 2026 Charles Wu.
Independent project; not affiliated with or endorsed by Higgsfield or any model/platform vendor.
Research acknowledgement: design was informed in part by study of the publicly released HELL GRIND project. No HELL GRIND production Materials are distributed here.
