# Third-Party Notices
AI Film Director is independently written. This public package does **not** include HELL GRIND character assets, likenesses, reference images, original prompts/prompt chains, raw generation data, source attachments, or other production Materials.

The design was informed in part by study and analysis of the publicly viewable HELL GRIND project by Higgsfield Studio. At review time HELL GRIND is marked `OWL-P-NL-1.0`, which places conditions on use/redistribution of released Materials, including platform restrictions, attribution, excluded-likeness rules and no repackaging as standalone prompt packs/datasets/presets/libraries.

This repository contains independently written abstractions and generic examples only. Its MIT License applies only to original AI Film Director code/documentation and does not relicense third-party works, trademarks, models, services or materials.

No affiliation or endorsement by Higgsfield is claimed.
